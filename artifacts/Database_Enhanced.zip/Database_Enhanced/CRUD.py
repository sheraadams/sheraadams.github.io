
# Shera Adams
# shera.adams@snhu.edu
# January 23,2024
# 
# Version: 2.0, This is an enhanced version of the CS340 Client-server dashboard project created for Southern New Hampshire University to 
# satisfy the databases category enhancement of CS499, Capstone class.
#
# The main purpose of CRUD.py is to establish a connection to the MongoDB database and provide create, read, update, delete functions for database interaction
# in our dashboard application. 
#
# Changes: I have added password handling to the init() method and I have added a database.close() function to ensure the deallocation of resources at termination. 
#
#Issues: none
from pymongo import MongoClient
import sys

class CRUD(object):

    def __init__(self, USER, PASS):      
        # connection variables
        HOST = 'localhost'
        PORT = 27017  # find this with Linux command: printenv | grep -i mongo
        DB = 'AAC'
        COL = 'animals'
        try: 
            # try the connection string
            self.client = MongoClient('mongodb://%s:%s@%s:%d' % 
                                    (USER, PASS, HOST, PORT))
            # define the database and the collection
            self.database = self.client['%s' % (DB)]
            self.collection = self.database['%s' % (COL)]
            # if connection is successful, print a message to the console.
            print("connection successful")
        except Exception as e:
            # if the connection is not successful, print a message to the console and exit the application
            print(f"Incorrect Password: {e}")
            sys.exit()
  
    # function to create a document in the database
    def create(self, data):
        # if there is data 
        if data is not None:
            # attempt to insert data, if successful return true
            try:
                result = self.collection.insert_one(data)
                return True if result.acknowledged else False
            # failure to insert data, raise exception and return false
            except Exception as e:
                print(f"Error creating document: {e}")
                return False
        # if no data, raise exception and return false
        else:
            raise Exception("Nothing to save because data parameter is empty")

    # Method to read a document or documents from our database
    def read(self, query):
        # try to read the data, if success return query
        try:
            results = list(self.collection.find(query))
            return results
        # error reading the data, print "error" and return empty list
        except Exception as e:
            print(f"Error reading documents: {e}")
            return []

    # Method to update a document in the database
    def update(self, query, replacement):
        # update 1 to many documents
        try:
            # update the query
            result = self.collection.update_many(query, {"$set": replacement})
            # get the count of the modified using built-in function
            print("Updated: " + str(result.modified_count))
            return result.modified_count  
        # 0 documents
        except Exception as e:
            print(f"Error updating documents: {e}")
            print("Updated: " + str(result.modified_count))
            return 0  
                            
    # Method to delete a document from the database
    def delete(self, query):
        # delete 1 to many documents
        try:
            # delete the query
            result = self.collection.delete_many(query)
            # get the count of the modified using built-in function
            print("Deleted: " + str(result.deleted_count))
            return result.modified_count  
        # 0 document
        except Exception as e:
            print(f"Error updating documents: {e}")

            return 0
        
    # function to close the database, deallocating resources when we are finished    
    def close(self):
        self.client.close()
        print("Database connection is now closed.")

