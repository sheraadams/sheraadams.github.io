
# Shera Adams
from pymongo import MongoClient


class CRUD(object):

    def __init__(self, USER, PASS):      
        # connection variables
        HOST = 'localhost'
        PORT = 27017  # find this with Linux command: printenv | grep -i mongo
        DB = 'AAC'
        COL = 'animals'

        self.client = MongoClient('mongodb://%s:%s@%s:%d' % 
                                  (USER, PASS, HOST, PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        print("connection successful")

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        # if there is data 
        if data is not None:
            # attempt to insert data, if successful return true
            try:
                result = self.collection.insert_one(data)
                return True if result.acknowledged else False
            # failure to insert data, raise exception and return false
            except Exception as e:
                print(f"Error creating document: {e}")
                return False
        # if no data, raise exception and return false
        else:
            raise Exception("Nothing to save because data parameter is empty")

# Create method to implement the R in CRUD.
    def read(self, query):
        # try to read the data, if success return query
        try:
            results = list(self.collection.find(query))
            return results
        # error reading the data, print "error" and return empty list
        except Exception as e:
            print(f"Error reading documents: {e}")
            return []

# Create method to implement the U in CRUD.
    def update(self, query, replacement):
        # update 1 to many documents
        try:
            # update the query
            result = self.collection.update_many(query, {"$set": replacement})
            # get the count of the modified using built-in function
            print("Updated: " + str(result.modified_count))
            return result.modified_count  
        # 0 document
        except Exception as e:
            print(f"Error updating documents: {e}")
            print("Updated: " + str(result.modified_count))
            return 0  
                            
    # Create method to implement the D in CRUD.
    def delete(self, query):
        # delete 1 to many documents
        try:
            # delete the query
            result = self.collection.delete_many(query)
            # get the count of the modified using built-in function
            print("Deleted: " + str(result.deleted_count))
            return result.modified_count  
        # 0 document
        except Exception as e:
            print(f"Error updating documents: {e}")

            return 0
